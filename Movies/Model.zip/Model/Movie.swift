//
//  Movie.swift
//  Movies
//
//  Created by Cristian Rojas on 07/09/2020.
//  Copyright © 2020 Cristian Rojas. All rights reserved.
//

import Foundation

struct Movie: Codable {
    let posterPath : String?
    let id: Int
    let title: String
    let overview: String
}
